package com.consulting_scholar;

import org.springframework.boot.SpringApplication;

public class TestConsultingScholarApplication {

	public static void main(String[] args) {
		SpringApplication.from(ConsultingScholarApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
